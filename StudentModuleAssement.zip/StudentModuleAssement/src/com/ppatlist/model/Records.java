package com.ppatlist.model;

public class Records {

	private int id;
	private String name;
	private String email;
	private String course;

	private String PpatCode;
	private String ColourCode;
	private String ColourDescription;	
	private int ColourSequence;	
	
	private String Organisation;
	private String CallNo;
	private String OrigCallNo;
	private String BarCode;
	private String QRCode;
	private String AccessionNo;
	private String CopyNo;
	private String Volume;
	private String ItemCategory;
	private String SMD;
	private String Location;
	private String Branch;
	private String Author;
	private String Title;
	private String AccessionYear;
	private String AccessionDate;
	private String Currency;
	private String ForeignCost;
	private String LocalCost;
	private String SpineSMD;
	private String SpineItemCategory;
	private String Subject;
	private String ClassNo;
	private String Cutter1;
	private String Cutter2;
	private String Cutter3;
	private String Year;
	private String SpineVolume;
	private String PartNo;
	private String SpineCopyNo;

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getPpatCode() {
		return PpatCode;
	}

	public void setPpatCode(String PpatCode) {
		this.PpatCode = PpatCode;
	}
	
	public String getColourCode() {
		return ColourCode;
	}

	public void setColourCode(String ColourCode) {
		this.ColourCode = ColourCode;
	}
	
	public String getColourDescription() {
		return ColourDescription;
	}

	public void setColourDescription(String ColourDescription) {
		this.ColourDescription = ColourDescription;
	}
	
	public int getColourSequence() {
		return ColourSequence;
	}

	public void setColourSequence(int ColourSequence) {
		this.ColourSequence = ColourSequence;
	}	
	
	

	public String getOrganisation() {
		return Organisation;
	}
	
	public void setOrganisation(String Organisation) {
		this.Organisation = Organisation;
	}	

	public String getCallNo() {
		return CallNo;
	}


	public void setCallNo(String callNo) {
		this.CallNo = callNo;
	}


	public String getOrigCallNo() {
		return OrigCallNo;
	}


	public void setOrigCallNo(String origCallNo) {
		this.OrigCallNo = origCallNo;
	}


	public String getBarCode() {
		return BarCode;
	}


	public void setBarCode(String barCode) {
		this.BarCode = barCode;
	}


	public String getQRCode() {
		return QRCode;
	}


	public void setQRCode(String qRCode) {
		this.QRCode = qRCode;
	}


	public String getAccessionNo() {
		return AccessionNo;
	}


	public void setAccessionNo(String accessionNo) {
		this.AccessionNo = accessionNo;
	}


	public String getCopyNo() {
		return CopyNo;
	}


	public void setCopyNo(String copyNo) {
		this.CopyNo = copyNo;
	}


	public String getVolume() {
		return Volume;
	}


	public void setVolume(String volume) {
		this.Volume = volume;
	}


	public String getItemCategory() {
		return ItemCategory;
	}


	public void setItemCategory(String itemCategory) {
		this.ItemCategory = itemCategory;
	}


	public String getSMD() {
		return SMD;
	}


	public void setSMD(String sMD) {
		this.SMD = sMD;
	}


	public String getLocation() {
		return Location;
	}


	public void setLocation(String location) {
		this.Location = location;
	}


	public String getBranch() {
		return Branch;
	}


	public void setBranch(String branch) {
		this.Branch = branch;
	}


	public String getAuthor() {
		return Author;
	}


	public void setAuthor(String author) {
		this.Author = author;
	}


	public String getTitle() {
		return Title;
	}


	public void setTitle(String title) {
		this.Title = title;
	}


	public String getAccessionYear() {
		return AccessionYear;
	}


	public void setAccessionYear(String accessionYear) {
		this.AccessionYear = accessionYear;
	}


	public String getAccessionDate() {
		return AccessionDate;
	}


	public void setAccessionDate(String accessionDate) {
		this.AccessionDate = accessionDate;
	}


	public String getCurrency() {
		return Currency;
	}


	public void setCurrency(String currency) {
		this.Currency = currency;
	}


	public String getForeignCost() {
		return ForeignCost;
	}


	public void setForeignCost(String foreignCost) {
		this.ForeignCost = foreignCost;
	}


	public String getLocalCost() {
		return LocalCost;
	}


	public void setLocalCost(String localCost) {
		this.LocalCost = localCost;
	}


	public String getSpineSMD() {
		return SpineSMD;
	}


	public void setSpineSMD(String spineSMD) {
		this.SpineSMD = spineSMD;
	}


	public String getSpineItemCategory() {
		return SpineItemCategory;
	}


	public void setSpineItemCategory(String spineItemCategory) {
		this.SpineItemCategory = spineItemCategory;
	}


	public String getSubject() {
		return Subject;
	}


	public void setSubject(String subject) {
		this.Subject = subject;
	}


	public String getClassNo() {
		return ClassNo;
	}


	public void setClassNo(String classNo) {
		this.ClassNo = classNo;
	}


	public String getCutter1() {
		return Cutter1;
	}


	public void setCutter1(String cutter1) {
		this.Cutter1 = cutter1;
	}


	public String getCutter2() {
		return Cutter2;
	}


	public void setCutter2(String cutter2) {
		this.Cutter2 = cutter2;
	}


	public String getCutter3() {
		return Cutter3;
	}


	public void setCutter3(String cutter3) {
		this.Cutter3 = cutter3;
	}


	public String getYear() {
		return Year;
	}


	public void setYear(String year) {
		this.Year = year;
	}


	public String getSpineVolume() {
		return SpineVolume;
	}


	public void setSpineVolume(String spineVolume) {
		this.SpineVolume = spineVolume;
	}


	public String getPartNo() {
		return PartNo;
	}


	public void setPartNo(String partNo) {
		this.PartNo = partNo;
	}


	public String getSpineCopyNo() {
		return SpineCopyNo;
	}


	public void setSpineCopyNo(String spineCopyNo) {
		this.SpineCopyNo = spineCopyNo;
	}


}

