package com.ppatlist.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.ppatlist.model.Records;

public class ListDaoImpl implements ListDao {

	private JdbcTemplate jdbcTemplate;

	public ListDaoImpl(DataSource dataSoruce) {
		jdbcTemplate = new JdbcTemplate(dataSoruce);
	}

	@Override
	public int create(Records student) {

		String sql = "insert into student1(stu_name,stu_email,stu_course) values(?,?,?)";

		try {

			int counter = jdbcTemplate.update(sql,
					new Object[] { student.getName(), student.getEmail(), student.getCourse() });
 
			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	public List<Records> read() {
		List<Records> studentList = jdbcTemplate.query("SELECT * FROM STUDENT1", new RowMapper<Records>() {

			@Override
			public Records mapRow(ResultSet rs, int rowNum) throws SQLException {
				Records student = new Records();

				student.setId(rs.getInt("stu_id"));
				student.setName(rs.getString("stu_name"));
				student.setEmail(rs.getString("stu_email"));
				student.setCourse(rs.getString("stu_course"));

				return student;
			}

		});

		return studentList;
	}

	@Override
	public List<Records> locationList() {
		List<Records> locationList = jdbcTemplate.query("SELECT spcharcolor.SP02CCODE,spcharcolor.SP02CDESC,spcharcolor.SP02COLSEQ, spcolor.SP01COLCODE FROM SPCHARCOLOR INNER JOIN spcolor ON spcharcolor.SP02COLSEQ=spcolor.SP01COLSEQ WHERE spcharcolor.SP02CTYPE = 'LOCATION'; ", new RowMapper<Records>() {
			
			@Override
			public Records mapRow(ResultSet rs, int rowNum) throws SQLException {
				Records location = new Records();

				location.setColourCode(rs.getString("SP01COLCODE"));
				location.setPpatCode(rs.getString("SP02CCODE"));
				location.setColourDescription(rs.getString("SP02CDESC"));
				location.setColourSequence(rs.getInt("SP02COLSEQ"));

				return location;
			}

		});

		return locationList;
	}	
	
	@Override
	public List<Records> findRecordById(int studentId) {

		List<Records> studentList = jdbcTemplate.query("SELECT * FROM STUDENT1 where stu_id=?",
				new Object[] { studentId }, new RowMapper<Records>() {

					@Override
					public Records mapRow(ResultSet rs, int rowNum) throws SQLException {
						Records student = new Records();

						student.setId(rs.getInt("stu_id"));
						student.setName(rs.getString("stu_name"));
						student.setEmail(rs.getString("stu_email"));
						student.setCourse(rs.getString("stu_course"));

						return student;
					}

				});

		return studentList;
	}

	@Override
	public int update(Records student) {
		String sql = "update  student1 set stu_name=?, stu_email=?, stu_course=? where stu_id=?";

		try {

			int counter = jdbcTemplate.update(sql,
					new Object[] { student.getName(), student.getEmail(), student.getCourse(), student.getId() });

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	public int delete(int studentId) {
		String sql = "delete from student1 where stu_id=?";

		try {

			int counter = jdbcTemplate.update(sql, new Object[] { studentId });

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

}
