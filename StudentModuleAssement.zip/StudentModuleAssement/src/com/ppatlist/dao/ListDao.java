package com.ppatlist.dao;

import java.util.List;

import com.ppatlist.model.Records;

public interface ListDao {

	public int create(Records student);

	public List<Records> read();
	
	public List<Records> locationList();	

	public List<Records> findRecordById(int studentId);

	public int update(Records student);

	public int delete(int studentId);

}
