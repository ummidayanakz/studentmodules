

Please change setting to jdk.
Please run project in main.jsp

Database username : root
password: localhost

###################